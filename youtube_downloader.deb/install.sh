#!/bin/bash
echo "Installing YouTube Downloader..."
cd ..
dpkg-deb --build youtube_downloader
sudo dpkg -i youtube_downloader.deb
echo "Done. You can launch the app from the menu or run: youtube-downloader"
