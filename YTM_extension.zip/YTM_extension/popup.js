document.getElementById("download").addEventListener("click", () => {
  const url = document.getElementById("url").value;
  const format = document.getElementById("format").value;

  fetch("http://localhost:5000/download", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url, format })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById("status").innerText = `Downloaded: ${data.filename}`;
  })
  .catch(err => {
    document.getElementById("status").innerText = `Error: ${err}`;
  });
});

